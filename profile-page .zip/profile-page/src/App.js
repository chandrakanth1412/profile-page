import React from "react";

function App() {
  return (
    <div className="min-h-screen bg-gray-100 flex items-center justify-center p-4">
      <div className="bg-white shadow-lg rounded-2xl p-6 w-full max-w-sm text-center">
        <img
          src="/image.jpg"
          alt="Chandrakanth Profile"
          className="w-32 h-32 rounded-full mx-auto mb-4"
        />
        <h1 className="text-2xl font-bold text-gray-800 mb-2">Nuthanaganti Chandrakanth</h1>
        <p className="text-gray-600 mb-4">
          Data Science student at MLR Institute of Technology. Passionate about DSA and full-stack MERN development. 
          Always learning and building web apps to sharpen my skills.
        </p>
        <h2 className="text-lg font-semibold text-gray-700 mb-2">Hobbies</h2>
        <ul className="list-disc list-inside text-gray-600 text-left mx-auto w-fit">
          <li>Surfing the Internet</li>
          <li>Learning New Things</li>
          <li>Watching Movies, Anime & Series</li>
        </ul>
      </div>
    </div>
  );
}

export default App;
